﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ContaOnline.Domain.Models;
using ContaOnline.Domain.Interfaces;
using ContaOnline.Repository;


namespace ContaOnline.Tests
{
    [TestClass]
    public class ContaCategoriaTeste
    {
        ContaCategoriaRepository repositorio = new ContaCategoriaRepository();

        [TestMethod]
        public void IncluirTest()
        {
            var conta = new ContaCategoria() { Id = "12345", Nome = "TesteContaCat", UsuarioId = "abc" };
            repositorio.Incluir(conta);
        }

        [TestMethod]
        public void AlterarTest()
        {
            var conta = new ContaCategoria() { Id = "12345", Nome = "AlterdoTesteContaCat", UsuarioId = "abc" };
            repositorio.Alterar(conta);
        }

        [TestMethod]
        public void ExcluirTest()
        {
            repositorio.Excluir("12345");
        }

        [TestMethod]
        public void ObterTodosTest()
        {
            var lista = repositorio.ObterTodos("abc");
            foreach(var conta in lista)
            {
                Exibir(conta);
            }
        }

        [TestMethod]
        public void ObterPorIdTest()
        {
            var conta= repositorio.ObterPorId("12345");
            if (conta != null)
            {
                Exibir(conta);
            }
            
        }














        private void Exibir(ContaCategoria conta)
        {
            Console.WriteLine(conta.Id);
            Console.WriteLine(conta.Nome);
            Console.WriteLine(conta.UsuarioId);
            Console.WriteLine();

        }
    }
}














