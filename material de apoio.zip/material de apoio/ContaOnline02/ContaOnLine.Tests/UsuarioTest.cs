﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ContaOnline.Domain.Models;
using ContaOnline.Repository;

namespace ContaOnline.Tests
{
    [TestClass]
    public class UsuarioTest
    {

        [TestMethod]
        public void UsuarioObterPorEmailSenhaTest()
        {

            var repositorio = new UsuarioRepository();
            var usuario = repositorio.ObterPorEmailSenha("teste@teste.com.br", "123");
            if (usuario != null)
            {
                Console.WriteLine(usuario.Id);
                Console.WriteLine(usuario.Nome);
                Console.WriteLine(usuario.Email);
                Console.WriteLine(usuario.Senha);
            }
        }



        [TestMethod]
        public void UsuarioExcluirTest()
        {
            
            var repositorio = new UsuarioRepository();
            repositorio.Excluir("123Teste");

        }



        [TestMethod]
        public void UsuarioAlterarTest()
        {
            var usuario = new Usuario()
            {
                Id = "123Teste",
                Nome = "Teste Alteração Rep",
                Email = "TesteAlterado@teste.com.br",
                Senha = "123Alterado"
            };

            var repositorio = new UsuarioRepository();
            repositorio.Alterar(usuario);
            
        }


        [TestMethod]
        public void UsuarioObterPorIdTest()
        {
            
            var repositorio = new UsuarioRepository();
            var usuario = repositorio.ObterPorId("123Teste");
            if(usuario!=null)
            {
                Console.WriteLine(usuario.Id);
                Console.WriteLine(usuario.Nome);
                Console.WriteLine(usuario.Email);
                Console.WriteLine(usuario.Senha);
            }
        }


        [TestMethod]
        public void UsuarioIncluirTest()
        {
            var usuario = new Usuario()
            {
                Id = "123Teste",
                Nome = "Teste Rep",
                Email = "Teste@teste.com.br",
                Senha = "123"
            };
            var repositorio = new UsuarioRepository();
            repositorio.Incluir(usuario);


        }






        [TestMethod]
        public void UsuarioObterTodosTest()
        {
            var rep = new UsuarioRepository();
            var lista = rep.ObterTodos(null);
            foreach(var usuario in lista)
            {
                Console.WriteLine(usuario.Nome);
                Console.WriteLine(usuario.Email);
            }

        }


        [TestMethod]
        public void UsuarioValidarNome()
        {
            var usuario = new Usuario()
            {
                Email = "teste@teste.com.br",
                Id = "1",
                Senha = "12334"
            };

            var erros = usuario.Validar();
            Assert.AreEqual(1, erros.Count, "Deveria retornar 1 erro");
        }
        [TestMethod]
        public void UsuarioValidarSenha()
        {
            var usuario = new Usuario()
            {
                Nome="Maria",
                Email = "teste@teste.com.br",
                Id = "1",
                Senha = "123"
            };

            var erros = usuario.Validar();
            Assert.AreEqual(1, erros.Count, "Deveria retornar 1 erro");
            Assert.AreEqual(erros[0], "A senha deve ter 5 caracteres no mínimo", "Mensagem Errada");
        }
    }
}
