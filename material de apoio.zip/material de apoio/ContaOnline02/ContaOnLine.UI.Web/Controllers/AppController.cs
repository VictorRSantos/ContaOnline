﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ContaOnline.UI.Web.Controllers
{
    public class AppController : Controller
    {
       /// <summary>
       /// Tela Inicial
       /// </summary>
       /// <returns></returns>
        public ActionResult Inicio()
        {
            return View();
        }

        /// <summary>
        /// Registro de Usuário
        /// </summary>
        /// <returns></returns>
        public ActionResult Registro()
        {
            return View();
        }

        /// <summary>
        /// Sobre este aplicativo
        /// </summary>
        /// <returns></returns>
        public ActionResult Sobre()
        {
            return View();
        }
    }
}