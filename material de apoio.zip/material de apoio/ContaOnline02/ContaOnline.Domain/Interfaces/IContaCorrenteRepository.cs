﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ContaOnline.Domain.Models;

namespace ContaOnline.Domain.Interfaces
{
    public interface IContaCorrenteRepository:IRepository<ContaCorrente>
    {
    }
}
