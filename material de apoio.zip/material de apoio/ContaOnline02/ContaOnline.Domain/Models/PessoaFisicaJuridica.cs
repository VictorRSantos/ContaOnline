﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContaOnline.Domain.Models
{
    public enum PessoaFisicaJuridica {   PessoaFisica=1, PessoaJuridica=2}
}
