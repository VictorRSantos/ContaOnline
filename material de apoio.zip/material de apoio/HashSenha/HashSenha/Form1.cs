﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HashSenha
{
    public partial class Form1 : Form
    {
        public string CriarHash(string texto)

        {
            var md5 = MD5.Create();
            byte[] bytes = System.Text.Encoding.ASCII.GetBytes(texto);
            byte[] hash = md5.ComputeHash(bytes);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }
            return sb.ToString();

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void criarSenhaButton_Click(object sender, EventArgs e)
        {
            string senhaHash = CriarHash(senhaTextBox.Text);
            hashTextBox.Text = senhaHash;

        }

        private void confirmarButton_Click(object sender, EventArgs e)
        {
            string senha = CriarHash(verificarTextBox.Text);
            string senhaArmazenada = hashTextBox.Text;
            if(senha==senhaArmazenada)
            {
                MessageBox.Show("Senha OK", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Senha invalida", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
