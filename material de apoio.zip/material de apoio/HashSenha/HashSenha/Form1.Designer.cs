﻿namespace HashSenha
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.criarSenhaButton = new System.Windows.Forms.Button();
            this.senhaTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.hashTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.verificarTextBox = new System.Windows.Forms.TextBox();
            this.confirmarButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // criarSenhaButton
            // 
            this.criarSenhaButton.Location = new System.Drawing.Point(168, 19);
            this.criarSenhaButton.Name = "criarSenhaButton";
            this.criarSenhaButton.Size = new System.Drawing.Size(75, 23);
            this.criarSenhaButton.TabIndex = 0;
            this.criarSenhaButton.Text = "Criar  Hash";
            this.criarSenhaButton.UseVisualStyleBackColor = true;
            this.criarSenhaButton.Click += new System.EventHandler(this.criarSenhaButton_Click);
            // 
            // senhaTextBox
            // 
            this.senhaTextBox.Location = new System.Drawing.Point(62, 22);
            this.senhaTextBox.Name = "senhaTextBox";
            this.senhaTextBox.Size = new System.Drawing.Size(100, 20);
            this.senhaTextBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Senha:";
            // 
            // hashTextBox
            // 
            this.hashTextBox.Location = new System.Drawing.Point(15, 58);
            this.hashTextBox.Multiline = true;
            this.hashTextBox.Name = "hashTextBox";
            this.hashTextBox.Size = new System.Drawing.Size(228, 101);
            this.hashTextBox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 176);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Conferir:";
            // 
            // verificarTextBox
            // 
            this.verificarTextBox.Location = new System.Drawing.Point(62, 173);
            this.verificarTextBox.Name = "verificarTextBox";
            this.verificarTextBox.Size = new System.Drawing.Size(100, 20);
            this.verificarTextBox.TabIndex = 5;
            // 
            // confirmarButton
            // 
            this.confirmarButton.Location = new System.Drawing.Point(168, 170);
            this.confirmarButton.Name = "confirmarButton";
            this.confirmarButton.Size = new System.Drawing.Size(75, 23);
            this.confirmarButton.TabIndex = 4;
            this.confirmarButton.Text = "Verificar";
            this.confirmarButton.UseVisualStyleBackColor = true;
            this.confirmarButton.Click += new System.EventHandler(this.confirmarButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(262, 205);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.verificarTextBox);
            this.Controls.Add(this.confirmarButton);
            this.Controls.Add(this.hashTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.senhaTextBox);
            this.Controls.Add(this.criarSenhaButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button criarSenhaButton;
        private System.Windows.Forms.TextBox senhaTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox hashTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox verificarTextBox;
        private System.Windows.Forms.Button confirmarButton;
    }
}

